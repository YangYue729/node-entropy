import utils
import torch.utils.data as data
from utils.get_log import log_recorder
from torchvision import transforms
import torch
import time
import pandas as pd

DEVICE = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
num_workers = 8
batch_size = 1
test_size = int(batch_size)

data_type = 'AID'
# 原图
filePath = '/root/projects/yy/datasets/AID/'

num_classes = 30
classifier_name = 'ResNet18'

ComIndex = 1

base_path = '/root/projects/yy/new_20220619_AID/'
lab_path = base_path + 'all_data/'
lab_name = 'AID_lablist.csv'
lab_data = pd.read_csv(lab_path + lab_name, header=None)[0]
lab_data1 = lab_data.tolist()

print(filePath)
time.sleep(3)

cate_path = base_path + 'all_data/'
# 所有池数据和测试数据

transform = {
    "train": transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])]),
    "test": transforms.Compose([transforms.ToTensor(),
                                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])}

recoder = log_recorder(data_type, classifier_name, filePath, batch_size)
# 选择分类模型
classifier = utils.model_select(classifier_name, 3, num_classes, DEVICE)

###############

model_ns = {0: 'AID_ResNet18_random_step1_bal_re1_0.4943181872367859_1.9697203636169434_192'}
for mod_index in range(0, 1):
    # model_n = 'mini_10_ResNet18_random_step10_bal_com1__re1_299_top_0.8920000195503235'
    # model_n = 'mini_10_ResNet18_random_step1_bal_com1_re1_0.5020000338554382_0.4710095226764679_283'

    # for lab_index in range(0, 1):
    model_n = model_ns[mod_index]
    m = model_n.split('_')
    step_index = 1
    # re_index = m[6]
    # mod = m[3]

    file_dir = base_path + 'Model/ran_20220619/'
    # file_dir = base_path + 'Model/mini10_ran_com1_20220510/'
    testset_name = 'AID_all.csv'
    # testset_name = 'mini10_0608_ep{}_train_other'.format(step_index)
    test_set = utils.YDataset(filePath, cate_path + testset_name, num_classes, lab_data1,
                              transform['test'])

    test_loader = data.DataLoader(
        dataset=test_set,
        batch_size=test_size,
        shuffle=True,
        num_workers=0)
    testDataiter = iter(test_loader)

    save_path = base_path + 'step{}_ran/'.format(step_index)
    trained_classifier_name = file_dir + model_n
    trained_para = torch.load(trained_classifier_name, map_location=torch.device(DEVICE))
    new_state_dict = dict()
    for k, v in trained_para.items():
        if k[:7] == 'module.':
            name = k[7:]  # remove `module.` ## 多gpu 训练带moudule默认参数名字,预训练删除
        else:
            name = k
        new_state_dict[name] = v
    classifier.load_state_dict(new_state_dict)
    # 并行化
    # classifier = nn.DataParallel(classifier).to(DEVICE)
    # 检测是否正常传回
    # len_test = 0
    len_test = utils.for_embedding(classifier, DEVICE, testDataiter, data_type, save_path, test_set, batch_size, tp=True)

    print('基于{}模型的{}中的{}数据的第{}_{}个特征提取器的embedding已完成，编码数据为{}条'.format(
        classifier_name, data_type, testset_name, step_index, 'ran', len_test))