# -*- coding: utf-8 -*-

"""
Created on 

@file: FCN.py
@author: ZhangZ

"""
from torch import nn
import torch.nn.functional as F


class FCN(nn.Module):

    def __init__(self, classnum, device):
        super(FCN, self).__init__()
        self.DEVICE = device
        self.hidden_layer_1 = nn.Conv1d(1, 128, kernel_size=9, padding=4, bias=False)
        self.hidden_layer_2 = nn.Conv1d(128, 256, kernel_size=5, padding=2, bias=False)
        self.hidden_layer_3 = nn.Conv1d(256, 128, kernel_size=3, padding=1, bias=False)
        self.bn1 = nn.BatchNorm1d(128)
        self.bn2 = nn.BatchNorm1d(128 * 2)
        self.bn3 = nn.BatchNorm1d(128)

        self.AAPool = nn.AdaptiveAvgPool1d(1)
        self.output_layer = nn.Linear(128, classnum)


    def forward(self, x):
        x = x.clone().detach().float().transpose(1, 2)
        # print('x:',x.shape)
        # [batch_size, input_size, length]
        out = F.relu(self.bn1(self.hidden_layer_1(x)))
        out = F.relu(self.bn2(self.hidden_layer_2(out)))
        out = F.relu(self.bn3(self.hidden_layer_3(out)))
        out = self.AAPool(out)
        # print('avg_pool2d:',out.shape)
        out = out.view(out.size(0), -1)
        # print(out.shape)
        out = self.output_layer(out)

        return out