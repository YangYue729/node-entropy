# -*- coding: utf-8 -*-

"""
Created on 

@file: LSTM.py
@author: ZhangZ

"""
from torch import nn
import torch.nn.functional as F
import torch


class LSTM(nn.Module):

    def __init__(self,input_num, classnum, device):
        super(LSTM, self).__init__()
        self.DEVICE = device
        self.embedding_layer = nn.Linear(input_num, 256)
        self.lstm = nn.LSTM(256,
                            256,
                            1,
                            batch_first=True,
                            dropout=0,
                            bidirectional=True)
        self.output_layer = nn.Linear(2*256, classnum)

    def forward(self, x):
        x = x.clone().detach().float()
        # print('x:',x.shape)
        # [batch_size, length, input_size]
        x = self.embedding_layer(x)
        output, _ = self.lstm(x)
        output = output[:, -1, :].squeeze()
        out = self.output_layer(output)
        return out