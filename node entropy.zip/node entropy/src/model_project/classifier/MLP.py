# -*- coding: utf-8 -*-
"""
Created on Sat Jun  6 14:28:44 2020

@author: z2379
"""
from torch import nn
import torch.nn.functional as F


class MLP(nn.Module):
    def __init__(self, num_classes, DEVICE):
        super(MLP, self).__init__()
        self.DEVICE = DEVICE
        length = 500
        channel = 1
        self.dropout1 = nn.Dropout(p=0.1)
        self.layer1 = nn.Linear(length * channel, 500)
        self.dropout2 = nn.Dropout(p=0.2)
        self.layer2 = nn.Linear(500, 500)
        self.dropout3 = nn.Dropout(p=0.2)
        self.layer3 = nn.Linear(500, 500)
        self.dropout4 = nn.Dropout(p=0.3)
        self.layer4 = nn.Linear(500, num_classes)

    def forward(self, x):
        x = x.clone().detach().float().transpose(1, 2)
        # print('x:',x.shape)
        # [batch_size, input_size, length]
        x = x.squeeze(1).view(x.size(0), -1)
        # [batch_size, length*channel]
        y = F.relu(self.layer1(self.dropout1(x)))
        y = F.relu(self.layer2(self.dropout2(y)))
        y = F.relu(self.layer3(self.dropout3(y)))
        out = F.relu(self.layer4(self.dropout4(y)))

        return out
