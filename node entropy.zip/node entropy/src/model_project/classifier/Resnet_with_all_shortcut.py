from torch import nn
import torch.nn.functional as F


# 用于ResNet18和34的残差块，用的是2个3x3的卷积
class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, in_planes, channel_group, stride=1):
        super(BasicBlock, self).__init__()
        self.conv1 = nn.Conv1d(in_planes, channel_group[0], kernel_size=3,
                               stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm1d(channel_group[0])
        self.conv2 = nn.Conv1d(channel_group[0], channel_group[1], kernel_size=3,
                               stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm1d(channel_group[1])

        self.conv_shortcut = nn.Conv1d(in_planes, channel_group[1],
                                       kernel_size=1, stride=stride, bias=False)
        self.bn_shortcut = nn.BatchNorm1d(channel_group[1])

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += self.bn_shortcut(self.conv_shortcut(x))
        out = F.relu(out)
        # print(out.shape)
        return out


class ResNet(nn.Module):
    def __init__(self, d_input, block, channels, num_blocks, num_classes, DEVICE):
        super(ResNet, self).__init__()
        self.in_planes = channels[0]
        k = 1
        channel_group = []
        for i in num_blocks:
            t = []
            for j in range(i):
                t.append(channels[k:k + 3])
                k += 3
            channel_group.append(t)

        self.DEVICE = DEVICE
        self.conv1 = nn.Conv1d(d_input, self.in_planes, kernel_size=3,
                               stride=1, padding=1, bias=False)
        self.bn1 = nn.BatchNorm1d(self.in_planes)

        self.layer1 = self._make_layer(block, channel_group[0], num_blocks[0], stride=1)
        self.layer2 = self._make_layer(block, channel_group[1], num_blocks[1], stride=2)
        self.layer3 = self._make_layer(block, channel_group[2], num_blocks[2], stride=2)
        self.layer4 = self._make_layer(block, channel_group[3], num_blocks[3], stride=2)
        self.AAPool = nn.AdaptiveAvgPool1d(1)
        # print(channel_group)
        # print(channel_group[-1][-1][-1])
        self.linear = nn.Linear(channel_group[-1][-1][-2] * block.expansion, num_classes)

    def _make_layer(self, block, channel_group, num_blocks, stride):
        strides = [stride] + [1] * (num_blocks - 1)
        layers = []
        for i, stride in enumerate(strides):
            layers.append(block(self.in_planes, channel_group[i], stride))
            self.in_planes = channel_group[i][1] * block.expansion
        return nn.Sequential(*layers)

    def forward(self, x):
        x = x.clone().detach().float().transpose(1, 2).to(self.DEVICE)
        # print('x:', x.shape)
        out = F.relu(self.bn1(self.conv1(x)))
        # print('con1:',out.shape)
        out = self.layer1(out)
        # print('layer1:',out.shape)
        out = self.layer2(out)
        # print('layer2:',out.shape)
        out = self.layer3(out)
        # print('layer3:',out.shape)
        out = self.layer4(out)
        # print('layer4:',out.shape)
        # out = F.avg_pool2d(out, out.shape[2,3])
        out = self.AAPool(out)
        # print('avg_pool2d:',out.shape)
        out = out.view(out.size(0), -1)
        # print(out.shape)
        out = self.linear(out)
        # print(out.shape)
        return out


def ResNetAll(d_input, num_classes, DEVICE, channels=None):
    if channels is None:
        channels = [64,
                    64, 64, 64,
                    64, 64, 64,
                    128, 128, 128,
                    128, 128, 128,
                    256, 256, 256,
                    256, 256, 256,
                    512, 512, 512,
                    512, 512, 512]
    return ResNet(d_input, BasicBlock, channels, [2, 2, 2, 2], num_classes, DEVICE)
