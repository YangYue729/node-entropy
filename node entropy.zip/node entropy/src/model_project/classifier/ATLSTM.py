# -*- coding: utf-8 -*-

"""
Created on 

@file: ATLSTM.py
@author: ZhangZ

"""
from torch import nn
import torch.nn.functional as F
import torch


class ATLSTM(nn.Module):

    def __init__(self, input_num, classnum, device):
        super(ATLSTM, self).__init__()
        self.DEVICE = device
        self.embedding_layer = nn.Linear(input_num, 256)
        self.lstm = nn.LSTM(256,
                            256,
                            1,
                            batch_first=True,
                            dropout=0,
                            bidirectional=True)
        self.attention_layer = AttentionLayer(256, 2)
        self.output_layer = nn.Linear(256, classnum)

    def forward(self, x):
        x = x.clone().detach().float()
        # print('x:',x.shape)
        # [batch_size, length, input_size]
        x = self.embedding_layer(x)
        output, _ = self.lstm(x)
        output = self.attention_layer(output)
        out = self.output_layer(output)

        return out


class AttentionLayer(nn.Module):

    def __init__(self, hidden_size, bidirectional):
        super(AttentionLayer, self).__init__()

        # 此处可以并行化优化
        self.k_net = nn.Linear(hidden_size * bidirectional, hidden_size)
        self.q_net = nn.Linear(hidden_size * bidirectional, hidden_size)
        self.v_net = nn.Linear(hidden_size * bidirectional, hidden_size)

    def forward(self, r_out):
        # r_out shape (batch, time_step, output_size*bi_lstm)
        key = self.k_net(r_out)
        query = self.q_net(r_out)
        value = self.v_net(r_out)
        alpha = key.mul(query)
        alpha = torch.nn.functional.adaptive_avg_pool1d(alpha, 1)
        alpha = F.softmax(alpha, dim=1)
        out = torch.sum(value * alpha, 1)
        return out

