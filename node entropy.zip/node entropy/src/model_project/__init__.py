from .classifier.Resnet_with_all_shortcut import ResNetAll
from .classifier.Transformer import Transformer
from .classifier.Resnet import ResNet34
from .classifier.Resnet import ResNet18
from .classifier.ATLSTM import ATLSTM
from .classifier.LSTM import LSTM
from .classifier.VGG import vgg16