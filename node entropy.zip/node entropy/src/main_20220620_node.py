import csv
import pandas as pd
import numpy as np
from tqdm import tqdm
import math

base_path = '/root/projects/yy/new_20220619_RSSCN7/'

dis_path = base_path + 'cal/'
cate_path = base_path + 'all_data/'
node_path = base_path + 'nod_name/'
dis_class = 'base'
class_size = 7
sec_num = 5
for class_i in range(class_size):
    val = []
    cate_name = 'RSSCN7_l{}_{}.csv'.format(class_i, dis_class)
    cate_data = pd.read_csv(cate_path + cate_name, header=None)[0]
    dis_name = 'RSSCN7_random_{}_l{}_data&data_distance_fast.csv'.format(dis_class, class_i)
    dis_data = pd.read_csv(dis_path + dis_name, header=None)

    max_name = []
    for sec_index in range(sec_num):
        if sec_index == 0:
            dis_data = dis_data
        else:
            dis_name = 'RSSCN7_random_{}_l{}_data&data_distance_fast_add.csv'.format(dis_class, class_i)
            dis_data = pd.read_csv(dis_path + dis_name, header=None)
        # print(dis_data)
        length = len(dis_data)
        # print(length)
        # # 距离值排序
        for i_index in range(length):
            for j_index in range(i_index + 1, length):
                data_str = dis_data.iloc[i_index][j_index]
                # print(data_str)
                val.append(data_str)
        # print(val)
        val_length = len(val)
        val_sort = sorted(val)
        # 四分位数
        cir_index = int(0.25 * val_length)
        cir_val = val_sort[cir_index]

        # print(cir_val)
        # print(val_sort)
        dis_save = np.zeros(length, dtype=int)
        dis_data = pd.DataFrame(dis_data)
        # print(dis_data.iloc[1][1])
        for point_index in tqdm(range(0, length)):
            point_num = 0
            for point_index1 in range(0, length):
                dis_point = dis_data.iloc[point_index][point_index1]
                if dis_point < cir_val:
                    point_num += 1
            dis_save[point_index] = point_num
        print(dis_save)

        # 定节点
        c_val1 = list(dis_save)
        pad = min(dis_save) - 1  # 最小值填充
        # print(pad)

        max_idx = c_val1.index(max(c_val1))  # 找最大值索引
        # print(max_idx)
        c_val1[max_idx] = pad  # 最大值填充
        max_name.append(cate_data.loc[max_idx])
        # length_max = len(max_name)

        print(max_name)

        # 删除节点相关信息
        del_num = 0
        # print(dis_data)

        for del_index in range(length):
            if del_index != max_idx:
                # print(dis_data)
                print(len(dis_data), max_idx, del_index)
                # print(dis_data.loc[14][0])
                # print(dis_data.loc[max_idx][del_index])

                del_point = dis_data.loc[max_idx][del_index]

                # print(max_idx, del_index, del_point)
                if del_point < cir_val:
                    del_num += 1
                    cate_data = cate_data.drop(labels=del_index)
                    cate_data = cate_data.drop(labels=del_index)
                    dis_data = dis_data.drop(labels=del_index, axis=0)
                    dis_data = dis_data.drop(labels=del_index, axis=1)
                    # dis_data = dis_data.reset_index(drop=True)

        cate_data = cate_data.drop(labels=max_idx)
        dis_data = dis_data.drop(labels=max_idx, axis=0)
        dis_data = dis_data.drop(labels=max_idx, axis=1)

        cate_data = cate_data.reset_index(drop=True)
        cate_length = len(cate_data)
        if cate_length == length - del_num:
            print('succ {}={}-{}'.format(cate_length, length, del_num))
        else:
            print('{}={}-{}'.format(cate_length, length, del_num))
        # dis_data = dis_data.reset_index(drop=True, axis=0)
        # dis_data = dis_data.reset_index(drop=True, axis=1)
        save_name_max = 'RSSCN7_random_{}_l{}_data&data_distance_fast_add.csv'.format(dis_class, class_i)
        f = open(dis_path + save_name_max, 'w', encoding='utf-8', newline='')
        csv_writer = csv.writer(f)
        for k in dis_data.values:
            csv_writer.writerow(k)
        f.close()

        if cate_length == 0:
            break

    print(max_name)
    max_name1 = pd.DataFrame(max_name)
    save_name_node = 'RSSCN7_l{}_{}_nod.csv'.format(class_i, dis_class)
    f = open(node_path + save_name_node, 'w', encoding='utf-8', newline='')
    csv_writer = csv.writer(f)
    for k in max_name1.values:
        csv_writer.writerow(k)
    f.close()

    # print(len(dis_list))

    # dis_data_sort = dis_data.sort_values()
    # print(dis_data_sort)
    # data_sort = dis_data_sort.reset_index(drop=True)
    # # length = len(data_sort)
    # # print(length)
    # # print(data_sort)
    # length = len(data_sort)
    # print(length)
    # index = int(length * 0.25 - 1)
    # rad = data_sort.iloc[index]
