import math
import time
import torch.nn.functional as F
from utils.my_forward import my_forward
import torch
from torch import nn
from tqdm import tqdm

'''
此代码功能为对数据进行一个EPOCH的训练

输入数据rcs的格式为：
[batch_size, time_steps, input_channel=1]
标签label格式为：
[batch_size, class_num]
输出output格式为：
[batch_size, class_num]

'''

#model, device, dataiter, optimizer, train_set, batch_size, viz, cur_epoch, recoder, tp=False

def train(model, device, dataiter, optimizer, train_set, batch_size, recoder, tp=False):  # 训练函数
    """

    此代码功能为对数据进行一个EPOCH的训练

    输入数据rcs的格式为：
    [batch_size, time_steps, input_channel=1]
    标签label格式为：
    [batch_size, class_num]
    输出output格式为：
    [batch_size, class_num]


    :param model: 深度学习模型
    :param device: 计算处理器设备
    :param dataiter: 数据迭代器
    :param optimizer: 优化器
    :param train_set: 训练集
    :param batch_size: 批大小
    :param mission: 任务类型
    :param recoder: 日志记录器
    :param tp: 是否记录结果
    :return: loss, acc
    """
    model.train()  # 将model设定为训练模式
    aloss = 0
    aacc = 0
    iter_times = math.ceil(len(train_set) / batch_size)
    for iteration in tqdm(range(iter_times)):
        data, label = next(dataiter)
        # data = data.clone().float().to(device)
        # data = data.clone().detach().to(device)
        data = data.to(device)
        label = label.to(device)
        loss, acc = my_forward(model, data, label, device, recoder, tp)

        #############
        # aacc += acc.cpu().detach().numpy()
        aacc += acc
        loss.backward()  # 针对损失函数的后向传播
        optimizer.step()  # 反向传播后的梯度下降
        optimizer.zero_grad()  # 清除旧的梯度信息
        aloss += loss
        # aloss += loss.cpu().detach().numpy()
        recoder.log_train_loss(loss)
        recoder.log_train_acc(acc)


    # return aloss / iter_times, aacc / iter_times
    return aloss / iter_times


# def train(model, device, dataiter, optimizer, train_set, batch_size, viz, cur_epoch, recoder, tp=False):  # 训练函数
#     model.train()  # 将model设定为训练模式
#     aloss = 0
#     iter_times = math.ceil(len(train_set) / batch_size)
#
#     for iteration in tqdm(range(iter_times)):
#         # 记录数据获取前的时刻
#         time1 = time.time()
#         img, label = next(dataiter)
#         # 记录数据获取后兼训练开始前时刻
#         time2 = time.time()
#         label = label.clone().detach().float().to(device)
#
#         output = F.softmax(model(img), dim=1)
#         # print(1)
#         corrent = torch.eq(torch.argmax(output, dim=1), torch.argmax(label, dim=1))
#
#         # 记录开始记录日志时刻时刻
#         time4 = time.time()
#         if tp:
#             # 记录当前batch的真值和预测结果
#             for i in range(len(torch.argmax(output, dim=1).cpu().numpy())):
#                 recoder.log_test_label(torch.argmax(label, dim=1).cpu().numpy()[i],
#                                        torch.argmax(output, dim=1).cpu().numpy()[i])
#         recoder.log_test_acc(torch.mean(corrent.float()))
#         # 记录训练结束时刻
#         time3 = time.time()
#         loss_function = nn.CrossEntropyLoss()
#         loss = loss_function(output, torch.argmax(label, dim=1))
#         # print(loss)
#         #recoder.log_train_loss(loss.item())
#         # viz.line(torch.FloatTensor([loss.item()]), torch.FloatTensor([iter_times * cur_epoch + iteration]), win=mission +'train_loss',
#         #          update='append')
#         aloss += loss
#         optimizer.zero_grad()  # 清除旧的梯度信息
#         loss.backward()  # 针对损失函数的后向传播
#         optimizer.step()  # 反向传播后的梯度下降
#         '''
#         print('获取数据所用时间:', time2 - time1)
#         print('训练所用时间:', time3 - time2)
#         print('记录日志所用时间:', time5 - time4)
#         '''
#
#     return aloss / iter_times
