import time
import torch.utils.data as Data
import pandas as pd
import numpy as np
import os
import re
from utils.awgn import awgn
from utils.config import trj
from utils.config import radar_position
from utils.position_code import pos_encode
from PIL import Image

'''
此代码功能为读取测试集数据

与原有代码的区别之处在于将文件名一并传回

'''


class YDataset(Data.Dataset):

    def __init__(self, filePath, file_catelog, num_classes, lab_data1, transform=None):
        self.filePath = filePath
        # self.filename_list = pd.read_csv('../' + file_catelog, header=None)[0]
        self.filename_list = pd.read_csv(file_catelog, header=None)
        self.num_classes = num_classes
        self.transform = transform
        self.lab_data1 = lab_data1

    def __len__(self):
        return len(self.filename_list)

    def __getitem__(self, index):
        # time_start = time.time()
        # # 样本名
        # # print(self.filename_list[index][0])
        if self.filename_list.values[index, 0][0] == '[':
            filename = self.filePath + self.filename_list.values[index, 0][2:-2]
            filename1 = self.filename_list.values[index, 0][2:-2]
            if self.filename_list.values[index, 0][2] == '[':
                filename = self.filePath + self.filename_list.values[index, 0][4:-4]
                filename1 = self.filename_list.values[index, 0][4:-4]

        else:
            filename = self.filePath + self.filename_list.values[index, 0]
            filename1 = self.filename_list.values[index, 0]
        # image_path = self.filePath + self.filename_list.values[index, 0][2:]
        # # filename = self.filename_list.values[index, 0][0: -4]
        # filename = self.filename_list.values[index, 0][2:]
        # mini / cifar10
        img_name = filename1
        # img_name = self.filename_list.values[index, 0]
        image_path = self.filePath + img_name
        # 原图
        # filename = filename
        img = Image.open(image_path).convert('RGB')
        img = self.transform(img)

        # filename = self.filename_list.values[index, 0]
        # print(filename)
        ###############
        ###############
        # # coil
        # lindex1 = self.filename_list.values[index, 0][5]
        # if lindex1 == '_':
        #     lindex2 = self.filename_list.values[index, 0][4]
        #     if lindex2 == '_':
        #         labelname = self.filename_list.values[index, 0][3]
        #         label = int(labelname)
        #     else:
        #         labelname = self.filename_list.values[index, 0][3:4]
        #         label = int(labelname)
        # else:
        #     labelname = self.filename_list.values[index, 0][3:5]
        #     label = int(labelname)

        # 17
        # label = self.filename_list.values[index, 1]

        # cifar10
        # labs = {
        #     'airplane': 0, 'automobile': 1, 'bird': 2, 'cat': 3, 'deer': 4,
        #     'dog': 5, 'frog': 6, 'horse': 7, 'ship': 8, 'truck': 9
        # }

        # mini10_com1
        labs = {'n02089867': 0, 'n02091244': 1, 'n02091831': 2, 'n02099601': 3, 'n01532829': 4,
                'n01558993': 5, 'n01843383': 6, 'n02129165': 7, 'n03272010': 8, 'n03773504': 9}

        # print(image_path)
        # cifar 10
        # lab_index = image_path.split('/')[8]
        # mini10 com1
        # lab_index = img_name.split('/')[0]
        # # print(lab_index)
        # label = int(self.lab_data1[lab_index])

        # # mini
        # labs = {
        #     'n01532829': 0, 'n02089867': 1, 'n02606052': 2,
        #     'n13133613': 3, 'n07747607': 4, 'n13054560': 5
        # }
        # n1305456000000792.jpg
        label_index = img_name[0:9]
        label = int(labs[label_index])

        # # mini100
        # label_index = img_name[0:9]
        # lab_data1 = self.lab_data1
        # label = int(lab_data1.index(label_index))
        # # label = int(lab_data1[label_index])

        # AID
        # label_index = img_name.split('/')[0]
        # lab_data1 = self.lab_data1
        # label = int(lab_data1.index(label_index))

        # # Toma
        # label_index = filename.split('/')[7]
        # # print(label_index)
        # label = int(label_index)

        # sub200
        # label = int(img_name.split('.')[0]) - 1

        return img, label, filename
