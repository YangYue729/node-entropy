# -*- coding: utf-8 -*-

"""
Created on 

@file: model_select.py
@author: ZhangZ

"""
import model_project


def model_select(model_name, input_num, num_classes, DEVICE):
    if model_name == 'SCN':
        return model_project.SCN(input_num, num_classes)
    elif model_name == 'ResNet18':
        return model_project.ResNet18(input_num, num_classes)
    elif model_name == 'ResNet34':
        return model_project.ResNet34(input_num, num_classes)
    elif model_name == 'ResNet50':
        return model_project.ResNet50(input_num, num_classes)
    elif model_name == 'ResNet101':
        return model_project.ResNet101(input_num, num_classes)
    elif model_name == 'ResNet152':
        return model_project.ResNet152(input_num, num_classes)
    elif model_name == 'VGG16':
        return model_project.vgg16(input_num, num_classes)
