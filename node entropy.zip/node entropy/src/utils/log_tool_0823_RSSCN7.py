# -*- coding: utf-8 -*-

"""
Created on

@file: log_tool.py
@author: YangY

"""
import csv
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import torch
from tqdm import tqdm
import re
import os
from visualization.log_ana import log_ana

# 分析该目录下的日志
# 日期
mod = 'ran'
datatype = 'RSSCN7'
data = '20220823'
base_path = '/root/projects/yy/new_20220619_RSSCN7/'
location = base_path + 'logs_ana/'
file_n = '{}_{}_{}'.format(data, datatype, mod)
file_dir = base_path + 'logs/{}'.format(data)
# /root/RCS/yy/rcs_d&l/Logs/0512test/ran5trj_test1_1/
print(file_dir)
ft = open(location + file_n + '.csv', 'w', encoding='utf-8', newline='')
for parent, dirnames, filenames in os.walk(file_dir):
    print(file_dir)
    print('parent:  ', parent)
    print('dirnames:  ', dirnames)  # 文件夹名称
    print('filenames:  ', filenames, '\n##########################')  # 文件夹下的文件
    for filename in filenames:
        # print(file_dir)
        temp = parent + '/' + filename
        #####################################
        data_name, classifier_name, dataset_name, batch_size, result = log_ana(parent, filename, datatype, mod)
        print(filename[:-4], data_name, classifier_name, dataset_name, batch_size, result)

        csv_writer_t = csv.writer(ft)
        csv_writer_t.writerow(
            [filename[:-4], data_name, classifier_name, dataset_name, batch_size, result[0], result[1], result[2]])

ft.close()
