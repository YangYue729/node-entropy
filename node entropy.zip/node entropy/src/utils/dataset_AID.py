import torch.utils.data as Data
import pandas as pd
from PIL import Image


class AidDataset(Data.Dataset):

    def __init__(self, filePath, file_catelog, num_classes, lab_data1, transform=None):
        self.filePath = filePath
        self.filename_list = pd.read_csv(file_catelog, header=None)[0]
        self.num_classes = num_classes
        self.transform = transform
        self.lab_data1 = lab_data1

    def __len__(self):
        return len(self.filename_list)

    def __getitem__(self, index):
        # time_start = time.time()
        # 样本名
        # # print(self.filename_list[index][0])
        # if self.filename_list[index][0] == '[':
        #     filename = self.filePath + self.filename_list[index][2:-2]
        #     if self.filename_list[index][2] == '[':
        #         filename = self.filePath + self.filename_list[index][4:-4]
        #
        # else:
        img_name = self.filename_list.values[index]
        image_path = self.filePath + img_name
        # 读取数据
        img = Image.open(image_path).convert('RGB')
        img = self.transform(img)
        # # mini
        # labs = {
        #     'n01532829': 0, 'n02089867': 1, 'n02606052': 2,
        #     'n13133613': 3, 'n07747607': 4, 'n13054560': 5
        # }
        # # n1305456000000792.jpg
        # label_index = img_name[0:9]
        # label = int(labs[label_index])
        # # print(label)

        # mini100
        label_index = img_name.split('/')[0]
        lab_data1 = self.lab_data1
        # com
        # label = int(lab_data1[label_index])
        # mini100
        label = int(lab_data1.index(label_index))
        # print(label_index, label)
        return img, label
