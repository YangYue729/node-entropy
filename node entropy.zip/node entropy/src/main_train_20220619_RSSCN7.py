from torch import optim
import utils
import model_project
import torch
import torch.utils.data as data
from visdom import Visdom
from utils.get_log import log_recorder
from torch import nn
from torch.optim import Adam
from torchvision import transforms
import os
import pandas as pd

DEVICE = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
# torch.cuda.set_device(1)
# os.environ["CUDA_VISIBLE_DEVICES"] = "1"

num_workers = 8  # 设置线程数，windows系统下只能单核读数据
base_path = '/root/projects/yy/new_20220619_RSSCN7/'
EPOCHs = 200  # 训练轮数
data_type = 'RSSCN7'
# missions = ['type']
# 数据集所在文件夹
filePath = '/root/projects/yy/datasets/RSSCN7/'
classifier_name = 'ResNet18'
batch_size = 24
# test_size = 1
# eval_size = 1
test_size = int(batch_size / 8)
eval_size = int(batch_size / 8)

num_classes = 7

# 实时可视化
# viz = Visdom()
# assert viz.check_connection()
viz = False

transform = {
    "train": transforms.Compose([transforms.RandomCrop(244, padding=4),
                                 transforms.RandomHorizontalFlip(),
                                 transforms.ToTensor(),
                                 transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])]),
    "test": transforms.Compose([transforms.Resize(244),
                                transforms.CenterCrop(244),
                                transforms.ToTensor(),
                                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])}

lab_path = base_path + 'all_data/'
lab_name = 'RSSCN7_lablist.csv'
lab_data = pd.read_csv(lab_path + lab_name, header=None)[0]
lab_data1 = lab_data.tolist()
for cindex in range(2, 3):
    for step_index in [1, 5, 4, 3, 2]:
        msavepath = base_path + 'Model/ran_20220619/'
        cate_path = base_path + 'traindata/'
        trainset_name = 'RSSCN7_step{}'.format(step_index)
        evalset_name = 'RSSCN7_test'
        testset_name = 'RSSCN7_test'
        # 数据集
        train_set = utils.AidDataset(filePath, cate_path + trainset_name + '.csv', num_classes, lab_data1,
                                     transform['train'])
        train_loader = data.DataLoader(
            dataset=train_set,
            batch_size=batch_size,
            shuffle=True,
            num_workers=num_workers)

        eval_set = utils.AidDataset(filePath, cate_path + evalset_name + '.csv', num_classes, lab_data1,
                                    transform['test'])
        eval_loader = data.DataLoader(
            dataset=eval_set,
            batch_size=eval_size,
            shuffle=True,
            num_workers=num_workers)

        test_set = utils.AidDataset(filePath, cate_path + testset_name + '.csv', num_classes, lab_data1,
                                    transform['test'])
        test_loader = data.DataLoader(
            dataset=test_set,
            batch_size=test_size,
            shuffle=True,
            num_workers=num_workers)

        #######################################
        # 声明日志记录器 data, model, dataset_name, batch_size, epoch, lr
        recoder = log_recorder(data_type, classifier_name, trainset_name, batch_size)
        # 选择分类模型
        classifier = utils.model_select(classifier_name, 3, num_classes, DEVICE)
        # 并行化
        # classifier = nn.DataParallel(classifier).to(DEVICE)
        classifier = classifier.to(DEVICE)
        # 设置学习率与优化器
        lr = 0.001  # 学习率
        optimizer = optim.Adam(classifier.parameters(), lr)  # 优化器
        # 引入余弦退火策略
        T_max = 10  # 学习率周期的迭代次数
        torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max, eta_min=0, last_epoch=-1)

        top_acc = 0
        # /root/projects/yy/new_pro/Model/resnet18sam1/
        # entry_sam_step{}+{}%test_unbal{}
        torch.save(classifier.state_dict(),
                   msavepath + '{}_{}_random_step{}_bal_re{}'
                   .format(data_type, classifier_name, step_index, cindex),
                   _use_new_zipfile_serialization=False)
        for i in range(EPOCHs):
            print('EPOCH:', i + 1)
            train_iter = iter(train_loader)
            test_iter = iter(test_loader)
            eval_iter = iter(eval_loader)
            ########################################
            loss = utils.train(classifier, DEVICE, train_iter, optimizer, train_set, batch_size, recoder)
            acc = utils.test(classifier, DEVICE, test_iter, test_set, test_size, recoder, tp=True)
            ########################################
            print('基于{}模型的{}数据，第{}次重复，bal方案，第{}个step,第{}个EPOCH的运算已经结束，当前轮训练loss为{}，当前轮测试acc为{}'.format(
                classifier_name, data_type, cindex, step_index, i, loss, acc))

            if top_acc < acc:
                torch.save(classifier.state_dict(),
                           msavepath + '{}_{}_random_step{}_bal_re{}_{}_{}_{}'
                           .format(data_type, classifier_name, step_index, cindex, acc, loss, i),
                           _use_new_zipfile_serialization=False)
                top_acc = acc
            if i == 199:
                torch.save(classifier.state_dict(),
                           msavepath + '{}_{}_random_step{}_bal_re{}_{}_top_{}'
                           .format(data_type, classifier_name, step_index, cindex, i, top_acc),
                           _use_new_zipfile_serialization=False)
        recoder.log_close()
