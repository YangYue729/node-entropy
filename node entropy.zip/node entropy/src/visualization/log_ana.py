# -*- coding: utf-8 -*-

"""
Created on 

@file: log_ana.py
@author: ZhangZ

"""
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import torch
from tqdm import tqdm
import re
import os


def log_ana(parent, filename, datatype, mod):
    # print(parent + '/' + filename)
    # 读取日志中的关键信息
    title = pd.read_table(parent + '/' + filename, nrows=5, header=0, sep=" ")
    # 读取日志中的数据
    df = pd.read_table(parent + '/' + filename, header=6, sep=" ")
    print(title)
    # 提取数据中的有用部分
    df_tp = df[df['Type'] == "truth/predict"]

    # 提取关键信息中的测试集信息
    data_name = title.values[0][-1]
    classifier_name = title.values[4][-1]
    # dataindex = title.values[2][-2]
    dataset_name = title.values[2][-1]
    batch_size = title.values[3][-1]
    # print(data_name)

    # 获取回归任务真值
    true = df_tp['num1'].values
    # 获取回归任务预测值
    pred = df_tp['num2'].values
    # # 计算根均方误差
    # rmse1 = torch.sqrt(
    #     torch.mean(torch.from_numpy(np.array(pred) - np.array(true)) ** 2))
    # 创建图片对象
    plt.title('log_name:' + filename)

    print('分类任务')
    cls_num = 7
    conf_mat = np.zeros([cls_num, cls_num])
    for i in range(len(df_tp['num1'].values)):
        true_i = int(np.array(df_tp['num1'].values[i]))
        pre_i = int(np.array(df_tp['num2'].values[i]))
        conf_mat[true_i, pre_i] += 1

    TPs = [0] * cls_num
    FPs = [0] * cls_num
    FNs = [0] * cls_num

    precision = [0] * cls_num
    recall = [0] * cls_num
    f1 = [0] * cls_num
    for i in range(len(conf_mat)):
        for j in range(len(conf_mat[0])):
            if i == j:
                TPs[i] += conf_mat[i][j]
            else:
                FPs[j] += conf_mat[i][j]
                FNs[i] += conf_mat[i][j]
    # print('TPs:', TPs)
    # print('FPs:', FPs)
    # print('FNs:', FNs)
    for i in range(len(conf_mat)):
        precision[i] = TPs[i] / (TPs[i] + FPs[i])
        recall[i] = TPs[i] / (TPs[i] + FNs[i])
        f1[i] = 2 * precision[i] * recall[i] / (precision[i] + recall[i])
        # a = TPs[i] + FPs[i]
        # b = TPs[i] + FNs[i]
        # if a == 0.0:
        #     precision[i] = 0.0
        #     if b == 0.0:
        #         recall[i] = 0.0
        #     else:
        #         recall[i] = TPs[i] / (TPs[i] + FNs[i])
        # else:
        #     precision[i] = TPs[i] / (TPs[i] + FPs[i])
        #     if b == 0.0:
        #         recall[i] = 0.0
        #     else:
        #         recall[i] = TPs[i] / (TPs[i] + FNs[i])
        # if (precision[i] + recall[i]) == 0.0:
        #     f1[i] = 0.0
        # else:
        #     f1[i] = 2 * precision[i] * recall[i] / (precision[i] + recall[i])
    # print('precision:', precision)
    # print('recall:', recall)
    # print('f1:', f1)
    # plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 可显示中文字符
    # plt.rcParams['axes.unicode_minus'] = False
    classes = list(range(cls_num))
    confusion_matrix = conf_mat

    plt.imshow(confusion_matrix, interpolation='nearest', cmap=plt.cm.Oranges)  # 按照像素显示出矩阵
    a = classifier_name.split('_')
    if datatype == 'mini10':
        if mod == 'ran':
            title_name = data_name + '_' + a[4] + '_' + a[5] + '_' + a[8] + '_' + a[10]
        elif mod == 'inter':
            title_name = data_name + '_' + a[3] + '_' + a[7] + '_' + a[6] + '_' + a[9] + '_' + a[11]
        elif mod == 'all':
            title_name = data_name + '_' + a[3] + '_' + a[9] + '_' + a[8] + '_' + a[7] + '_' + a[11] + '_' + a[13]
        elif mod == 'intra':
            title_name = data_name + '_' + a[3] + '_' + a[8] + '_' + a[7] + '_' + a[10] + '_' + a[12]
    elif datatype == 'cifar10':
        if mod == 'ran':
            title_name = data_name + '_' + a[3] + '_' + a[5] + '_' + a[6] + '_' + a[8]
        elif mod == 'inter':
            title_name = data_name + '_' + a[4] + '_' + a[3] + '_' + a[2] + '_' + a[7] + '_' + a[9]
        elif mod == 'ln+lj+ran':
            title_name = data_name + '_' + a[4] + '_' + a[3] + '_' + a[2] + '_' + a[7] + '_' + a[9]
        elif mod == 'ln+ran':
            title_name = data_name + '_' + a[4] + '_' + a[3] + '_' + a[2] + '_' + a[7] + '_' + a[9]
    elif datatype == 'toma10':
        #  toma_10_ResNet18_500random_step1_bal_re3_0.8232421875_0.2442382574081421_141
            title_name = data_name + '_' + a[4] + '_' + a[6] + '_' + a[7]
    elif datatype == 'RSSCN7':
            title_name = dataset_name
    else:
        print('EEROR:{}'.format(datatype))
    # print(title_name)
    plt.title(title_name)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=-45)
    plt.yticks(tick_marks, classes)

    thresh = confusion_matrix.max() / 2.
    # iters = [[i,j] for i in range(len(classes)) for j in range((classes))]
    # ij配对，遍历矩阵迭代器
    iters = np.reshape([[[i, j] for j in range(cls_num)] for i in range(cls_num)], (confusion_matrix.size, 2))
    for i, j in iters:
        plt.text(j, i, format(confusion_matrix[i, j]), fontsize=7)  # 显示对应的数字

    plt.ylabel('Truth')
    plt.xlabel('Pred')
    plt.tight_layout()

    print('某验证1结果：')
    result = [sum(precision)/10, sum(recall)/10, sum(f1)/10]
    # result = [sum(recall)]
    dirs = parent + 'images'
    if not os.path.exists(dirs):
        os.makedirs(dirs)
    print(dirs)
    plt.savefig(dirs + '/' + filename[0:-4] + title_name + '.png')
    plt.show()
    # classifier_name, data_length, radar_index, mission, freq, result = log_ana(parent, filename)
    return data_name, classifier_name, dataset_name, batch_size, result
