import csv
import pandas as pd
import numpy as np
from tqdm import tqdm
import math

base_path = '/root/projects/yy/new_20220619_AID/'

dis_path = base_path + 'cal/'
cate_path = base_path + 'all_data/'
node_path = base_path + 'nod_name/'
embedding_path = base_path + 'step1_ran/'
sec_save_path = base_path + 'sec_data/'
dis_class = 'pool'
class_size = 30
# step_index = 2
for step_index in range(2, 6):
    print(step_index)
    dis_name = 'AID_random_{}_data&data_distance_fast.csv'.format(dis_class)
    dis_data = pd.read_csv(dis_path + dis_name, header=None)
    # 节点数
    val = []
    length = len(dis_data)
    # print(length)
    # # 距离值排序
    for i_index in range(length):
        for j_index in range(i_index + 1, length):
            data_str = dis_data.iloc[i_index][j_index]
            # print(data_str)
            val.append(data_str)
    # print(val)
    val_length = len(val)
    val_sort = sorted(val)
    # 十分位数
    # cir_index = length + int(1)
    # cir_val = val_sort[cir_index]
    # print(cir_val)

    # 算节点熵
    node_name = 'AID_base_nod.csv'
    node_data = pd.read_csv(node_path + node_name, header=None)[0]
    pool_name = 'AID_pool.csv'
    pool_data = pd.read_csv(cate_path + pool_name, header=None)[0]
    node_length = len(node_data)
    pool_length = len(pool_data)
    pool_val = np.zeros(pool_length, dtype=float)
    for pool_index in range(pool_length):
        node_val = np.zeros(node_length, dtype=float)
        pool_i = pool_data.iloc[pool_index]
        embedding_name1 = pool_i[0:-4] + '.csv'
        pool_embedding = pd.read_csv(embedding_path + embedding_name1, header=None)[0]
        for node_index in range(node_length):
            node_i = node_data.iloc[node_index]
            embedding_name = node_i[0:-4] + '.csv'
            node_embedding = pd.read_csv(embedding_path + embedding_name, header=None)[0]
            x2 = np.sqrt(np.sum(np.square(pool_embedding - node_embedding)))
            node_val[node_index] = x2
        # print(node_val)
        node_val = node_val / sum(node_val)
        entropy_val = 0
        # print(node_val)
        for node_index1 in range(node_length):
            node_val_i = node_val[node_index1]
            # print(node_val_i)
            if node_val_i == 0:
                entropy_val += 0
            else:
                entropy_val += node_val_i * math.log(node_val_i, 2)
        pool_val[pool_index] = (-1) * entropy_val
    # print(pool_val)

    # 数据筛选，删除节点
    sec_name = []
    sec_num = int(0.25 * pool_length) * (step_index - 1)

    for sec_index in range(sec_num):
        if sec_index == 0:
            dis_data = dis_data
        else:
            dis_name = 'AID_random_{}_data&data_distance_fast_add.csv'.format(dis_class)
            dis_data = pd.read_csv(dis_path + dis_name, header=None)
        length = len(dis_data)
        pool_val_list = list(pool_val)
        pad = max(pool_val_list) + 1  # 最小值填充
        # print(pad)
        max_idx = pool_val_list.index(min(pool_val_list))  # 找最大值索引
        # print(max_idx)
        pool_val_list[max_idx] = pad  # 最大值填充
        sec_name.append(pool_data.loc[max_idx])
        pool_val = pd.DataFrame(pool_val)

        # # 删除这个数和节点信息
        # for del_index in range(length):
        #     if del_index != max_idx:
        #         # print(dis_data)
        #         del_point = dis_data.loc[max_idx][del_index]
        #         # print(del_point1)
        #         # print(max_idx, del_index, del_point)
        #         if del_point < cir_val:
        #             pool_val = pool_val.drop(labels=del_index)
        #             pool_data = pool_data.drop(labels=del_index)
        #             dis_data = dis_data.drop(labels=del_index, axis=0)
        #             dis_data = dis_data.drop(labels=del_index, axis=1)
        pool_val = pool_val.drop(labels=max_idx)
        pool_data = pool_data.drop(labels=max_idx)
        dis_data = dis_data.drop(labels=max_idx, axis=0)
        dis_data = dis_data.drop(labels=max_idx, axis=1)
        pool_val = pool_val.reset_index(drop=True)
        pool_data = pool_data.reset_index(drop=True)
        save_name_max = 'AID_random_{}_data&data_distance_fast_add.csv'.format(dis_class)
        f = open(dis_path + save_name_max, 'w', encoding='utf-8', newline='')
        csv_writer = csv.writer(f)
        for k in dis_data.values:
            csv_writer.writerow(k)
        f.close()

        # print('已选{}-{}个'.format(sec_num, sec_index))
    sec_length = len(sec_name)
    if sec_length == sec_num:
        sec_name1 = pd.DataFrame(sec_name)
        save_name_max = 'AID_step{}_sec.csv'.format(step_index)
        f = open(sec_save_path + save_name_max, 'w', encoding='utf-8', newline='')
        csv_writer = csv.writer(f)
        for k in sec_name1.values:
            csv_writer.writerow(k)
        f.close()
    else:
        print('ERROR--应该选出来{}，实际选出来{}')
