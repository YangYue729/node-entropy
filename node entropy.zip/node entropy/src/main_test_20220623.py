import os
import utils
import model_project
import torch
import torch.utils.data as data
# from utils.get_log import log_recorder
from utils.get_log_test20210817 import log_recorder
import time
from torch import nn
from torchvision import transforms
import pandas as pd

DEVICE = torch.device("cpu")
filePath = '/root/projects/yy/datasets/RSSCN7/'
num_workers = 8
data_name = 'RSSCN7'
# data_index = ['a', 'b', 'c', 'g']
eval_test_index = 1
num_classes = 7
model_names = 'ResNet18'
batch_size = 1
test_size = 1
base_path = '/root/projects/yy/new_20220619_RSSCN7/'
cate_path = base_path + 'test_20220822/'

lab_path = base_path + 'all_data/'
lab_name = 'RSSCN7_lablist.csv'
lab_data = pd.read_csv(lab_path + lab_name, header=None)[0]
lab_data1 = lab_data.tolist()
#########################
transform = {
    "train": transforms.Compose([transforms.ToTensor(),
                                 transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])]),
    "test": transforms.Compose([transforms.Resize(256),
                                transforms.CenterCrop(244),
                                transforms.ToTensor(),
                                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])}
#########################

print(filePath)
time.sleep(3)
########################################
# 日志
log_save_path = base_path + 'logs/'
# classifier = utils.model_select(model_names[time_length], output_size[mission], DEVICE)
# print(model_names[time_length])
classifier = utils.model_select(model_names, 3, num_classes, DEVICE)

# trained_classifier_name = '/root/projects/yy/new_20210827/Model/tezheng/cifar_ResNet18_tezheng{}'.format(1)
trained_classifier_path = base_path + 'Model/ran_20220619/'
classifier_names = {0: 'RSSCN7_ResNet18_random_step1_bal_re2_0.8021390438079834_0.2955893278121948_131'}
for model_index in range(0, 1):
    for mer_index in ['max', 'min']:
        testset_name = 'RSSCN7_{}_test_0822_end'.format(mer_index)
        test_set = utils.AidDataset(filePath, cate_path + testset_name + '.csv', num_classes, lab_data1,
                                     transform['test'])
        test_loader = data.DataLoader(
            dataset=test_set,
            batch_size=test_size,
            shuffle=False,
            num_workers=num_workers)
        testDataiter = iter(test_loader)
        trained_classifier_name = classifier_names[model_index]
        # trained_classifier_name = 'mini_10_ResNet18_random_step1_bal_com1_re1_0.5020000338554382_0.4710095226764679_283'
        trained_para = torch.load(trained_classifier_path + trained_classifier_name, map_location=torch.device(DEVICE))
        recoder = log_recorder(data_name, model_names, trained_classifier_name, testset_name, batch_size, log_save_path)
        new_state_dict = dict()
        for k, v in trained_para.items():
            # print(k[:7])
            if k[:7] == 'module.':
                name = k[7:]  # remove `module.` ## 多gpu 训练带moudule默认参数名字,预训练删除
            else:
                name = k
            new_state_dict[name] = v
        classifier.load_state_dict(new_state_dict)
        model_list = [classifier]

        # 日志
        output1 = utils.for_16_test(model_list, DEVICE, testDataiter, test_set, batch_size, recoder, model_index, log_save_path, tp=True)
        recoder.log_close()
